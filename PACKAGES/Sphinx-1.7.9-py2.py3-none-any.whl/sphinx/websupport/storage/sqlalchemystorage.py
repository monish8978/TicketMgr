# -*- coding: utf-8 -*-
"""
    sphinx.websupport.storage.sqlalchemystorage
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    An SQLAlchemy storage backend.

    :copyright: Copyright 2007-2018 by the Sphinx team, see AUTHORS.
    :license: BSD, see LICENSE for details.
"""

from sphinxcontrib.websupport.storage.sqlalchemystorage import SQLAlchemyStorage  # NOQA
